// ═══════════════════════════════════════
// Habuild To Do — Service Worker
// Handles background reminders even when
// the tab is hidden or on another tab
// ═══════════════════════════════════════

const SW_VERSION = 'habuild-sw-v1';
let reminderSchedule = [];
let todayKey = '';
let checkInterval = null;
let firedToday = {};

// ── Install & Activate ──
self.addEventListener('install', e => {
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(self.clients.claim());
  startChecking();
});

// ── Receive schedule from main page ──
self.addEventListener('message', e => {
  if (!e.data) return;

  if (e.data.type === 'SET_REMINDERS') {
    reminderSchedule = e.data.schedule || [];
    todayKey = e.data.todayKey || '';
    // Restore already-fired list from message
    firedToday = {};
    reminderSchedule.forEach(r => {
      // The main page already filtered out fired ones
    });
    startChecking();
  }
});

// ── Start the background check loop ──
function startChecking() {
  if (checkInterval) clearInterval(checkInterval);
  // Check every 15 seconds
  checkInterval = setInterval(checkNow, 15000);
  checkNow(); // immediate check
}

// ── Core check ──
function checkNow() {
  if (!reminderSchedule.length) return;

  const now = new Date();
  const hh = now.getHours().toString().padStart(2, '0');
  const mm = now.getMinutes().toString().padStart(2, '0');
  const hhmm = hh + ':' + mm;

  reminderSchedule.forEach(r => {
    if (r.time !== hhmm) return;
    if (firedToday[r.id + '_' + hhmm]) return; // already fired this minute

    firedToday[r.id + '_' + hhmm] = true;

    // First try to show via the open tab
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clients => {
      if (clients.length > 0) {
        // Tab is open — send message to show in-app popup
        clients.forEach(client => {
          client.postMessage({
            type: 'SHOW_REMINDER',
            title: r.title,
            sub: r.sub,
            icon: r.icon
          });
        });
      }

      // Always also fire a browser push notification (works even if tab hidden)
      showNotification(r.title, r.sub, r.icon);

      // Remove from schedule so it doesn't repeat
      reminderSchedule = reminderSchedule.filter(x => x.id !== r.id);
    });
  });
}

// ── Show browser notification ──
function showNotification(title, sub, icon) {
  const label = icon ? icon + ' ' + title : title;
  self.registration.showNotification(label, {
    body: sub || 'Tap to open Habuild',
    icon: '/favicon.ico',
    badge: '/favicon.ico',
    tag: 'habuild-' + Date.now(),
    requireInteraction: false,
    vibrate: [200, 100, 200],
    actions: [
      { action: 'done', title: '✓ Done' },
      { action: 'snooze', title: '😴 Snooze 15m' }
    ]
  }).catch(() => {
    // Notification API not available — silently fail
  });
}

// ── Handle notification click ──
self.addEventListener('notificationclick', e => {
  e.notification.close();

  if (e.action === 'snooze') {
    // Snooze — re-add to schedule 15 min later
    const n = e.notification;
    const snoozeTime = new Date(Date.now() + 15 * 60 * 1000);
    const hh = snoozeTime.getHours().toString().padStart(2, '0');
    const mm = snoozeTime.getMinutes().toString().padStart(2, '0');
    reminderSchedule.push({
      id: 'snooze_' + Date.now(),
      time: hh + ':' + mm,
      title: n.title,
      sub: n.body,
      icon: '⏰'
    });
    return;
  }

  // Open / focus the app tab
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clients => {
      if (clients.length > 0) {
        clients[0].focus();
      } else {
        self.clients.openWindow('./');
      }
    })
  );
});
